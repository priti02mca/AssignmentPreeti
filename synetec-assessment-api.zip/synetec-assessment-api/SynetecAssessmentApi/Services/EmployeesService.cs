﻿using Microsoft.EntityFrameworkCore;
using SynetecAssessmentApi.Domain;
using SynetecAssessmentApi.Dtos;
using SynetecAssessmentApi.Persistence;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

using System;

namespace SynetecAssessmentApi.Services
{
    public class EmployeesService : IEmployeesService
    {
        private readonly AppDbContext _dbContext;

        public EmployeesService()
        {
            var dbContextOptionBuilder = new DbContextOptionsBuilder<AppDbContext>();
            dbContextOptionBuilder.UseInMemoryDatabase(databaseName: "HrDb");

            _dbContext = new AppDbContext(dbContextOptionBuilder.Options);
        }

        public async Task<IEnumerable<Employee>> GetEmployeesAsync()
        {
            IEnumerable<Employee> employees = await _dbContext
                .Employees
                .Include(e => e.Department)
                .ToListAsync();

            return employees;
        }

        public async Task<Employee> GetEmployeesById(int selectedEmployeeId)
        {
            Employee employee = await _dbContext.Employees
              .Include(e => e.Department)
              .FirstOrDefaultAsync(item => item.Id == selectedEmployeeId);
            if(employee == null)
            {
                throw new ArgumentException();
            }
            return employee;
        }

        public int TotalSalary()
        {
            return (int)_dbContext.Employees.Sum(item => item.Salary);
        }
    }
}
