﻿namespace SynetecAssessmentApi.Dtos
{
    public class CalculateBonusDto
    {
        public int TotalBonusPoolAmount { get; set; }
        public int SelectedEmployeeId { get; set; }
    }
}
