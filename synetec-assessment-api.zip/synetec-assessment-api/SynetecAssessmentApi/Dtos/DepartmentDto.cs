﻿namespace SynetecAssessmentApi.Dtos
{
    public class DepartmentDto
    {
        public string Title { get; set; }
        public string Description { get; set; }
    }
}
