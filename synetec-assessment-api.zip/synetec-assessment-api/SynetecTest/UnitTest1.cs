using Moq;
using NUnit.Framework;
using SynetecAssessmentApi.Domain;
using SynetecAssessmentApi.Services;
using System.Threading.Tasks;

namespace SynetecTest
{
    public class Tests
    {
        private IEmployeesService _empService;
        private IBonusPoolService _bonusPoolService;
        [SetUp]
        public void Setup()
        {

        }

        [Test]
        public async Task GetEmployeesList()
        {
            Mock<IEmployeesService> mockEmp = new Mock<IEmployeesService>();
            //var result = mockEmp.Setup(t => t.GetEmployeesAsync())>);
            var result = await _empService.GetEmployeesAsync();

        }
    }
}